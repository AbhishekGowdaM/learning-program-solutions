import java.util.HashMap;

public class InventoryManager
{
    HashMap<Integer, Product> inventory = new HashMap<>();

    public void addProduct(Product p)
    {
        inventory.put(p.productId, p);
    }

    public void updateProduct(int productId, int quantity, double price)
    {
        if (inventory.containsKey(productId))
        {
            Product p = inventory.get(productId);
            p.quantity = quantity;
            p.price = price;
        } else
        {
            System.out.println("Product not found!");
        }
    }

    public void deleteProduct(int productId)
    {
        inventory.remove(productId);
    }

    public void printInventory()
    {
        for (Product p : inventory.values()) {
            System.out.println(p);
        }
    }

    public static void main(String[] args)
    {
        InventoryManager manager = new InventoryManager();
        manager.addProduct(new Product(1, "Laptop", 10, 50000));
        manager.addProduct(new Product(2, "Mouse", 50, 500));
        manager.updateProduct(1, 8, 52000);
        manager.deleteProduct(2);
        manager.printInventory();
    }
}
