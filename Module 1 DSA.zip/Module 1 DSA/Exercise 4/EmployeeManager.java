public class EmployeeManager {
    Employee[] employees = new Employee[100];  // fixed-size array
    int count = 0;

    public void addEmployee(Employee e) {
        if (count < employees.length) {
            employees[count++] = e;
        } else {
            System.out.println("Employee array is full.");
        }
    }

    public Employee searchEmployee(int id) {
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == id) {
                return employees[i];
            }
        }
        return null;
    }

    public void deleteEmployee(int id) {
        for (int i = 0; i < count; i++) {
            if (employees[i].employeeId == id) {
                for (int j = i; j < count - 1; j++) {
                    employees[j] = employees[j + 1];  // shift left
                }
                employees[--count] = null;
                System.out.println("Employee deleted.");
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void listEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();
        manager.addEmployee(new Employee(1, "Alice", "Manager", 75000));
        manager.addEmployee(new Employee(2, "Bob", "Developer", 60000));
        manager.addEmployee(new Employee(3, "Carol", "Analyst", 50000));

        System.out.println("All Employees:");
        manager.listEmployees();

        System.out.println("\nSearching for ID 2:");
        Employee found = manager.searchEmployee(2);
        System.out.println(found != null ? found : "Not Found");

        System.out.println("\nDeleting employee with ID 1:");
        manager.deleteEmployee(1);
        manager.listEmployees();
    }
}
