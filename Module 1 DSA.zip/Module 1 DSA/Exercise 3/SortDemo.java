public class SortDemo {

    // Bubble Sort
    public static void bubbleSort(Order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (orders[j].totalPrice > orders[j + 1].totalPrice) {
                    Order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }

    // Quick Sort
    public static void quickSort(Order[] orders, int low, int high) {
        if (low < high) {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(Order[] orders, int low, int high) {
        double pivot = orders[high].totalPrice;
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (orders[j].totalPrice <= pivot) {
                i++;
                Order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        Order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;
        return i + 1;
    }

    public static void printOrders(Order[] orders) {
        for (Order o : orders) {
            System.out.println(o);
        }
    }

    public static void main(String[] args) {
        Order[] orders = {
            new Order(101, "Anil", 2500.0),
            new Order(102, "Bina", 5500.5),
            new Order(103, "Chirag", 1500.0),
            new Order(104, "Diksha", 3500.25)
        };

        System.out.println("Original Orders:");
        printOrders(orders);

        // Bubble Sort
        bubbleSort(orders);
        System.out.println("\nSorted by Bubble Sort:");
        printOrders(orders);

        // Reset array
        orders = new Order[]{
            new Order(101, "Anil", 2500.0),
            new Order(102, "Bina", 5500.5),
            new Order(103, "Chirag", 1500.0),
            new Order(104, "Diksha", 3500.25)
        };

        // Quick Sort
        quickSort(orders, 0, orders.length - 1);
        System.out.println("\nSorted by Quick Sort:");
        printOrders(orders);
    }
}
