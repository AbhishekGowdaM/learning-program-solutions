public class TaskLinkedList {
    private TaskNode head;

    // Add a task at the end
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search task by ID
    public Task searchTask(int id) {
        TaskNode current = head;
        while (current != null) {
            if (current.task.taskId == id) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

    // Delete task by ID
    public void deleteTask(int id) {
        if (head == null) return;

        if (head.task.taskId == id) {
            head = head.next;
            System.out.println("Task deleted.");
            return;
        }

        TaskNode current = head;
        while (current.next != null && current.next.task.taskId != id) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
            System.out.println("Task deleted.");
        } else {
            System.out.println("Task not found.");
        }
    }

    // Traverse and print all tasks
    public void displayTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    public static void main(String[] args) {
        TaskLinkedList list = new TaskLinkedList();
        list.addTask(new Task(1, "Fix bug", "Pending"));
        list.addTask(new Task(2, "Write tests", "In Progress"));
        list.addTask(new Task(3, "Review PR", "Pending"));

        System.out.println("All Tasks:");
        list.displayTasks();

        System.out.println("\nSearching for task ID 2:");
        Task t = list.searchTask(2);
        System.out.println(t != null ? t : "Not Found");

        System.out.println("\nDeleting task ID 1:");
        list.deleteTask(1);

        System.out.println("\nUpdated Task List:");
        list.displayTasks();
    }
}
