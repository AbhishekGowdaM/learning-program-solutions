import java.util.Arrays;
import java.util.Comparator;

public class SearchDemo 
{

    public static Product linearSearch(Product[] products, String name)
    {
        for (Product p : products)
        {
            if (p.productName.equalsIgnoreCase(name))
            {
                return p;
            }
        }
        return null;
    }

    // Binary search
    public static Product binarySearch(Product[] products, String name)
    {
        int left = 0, right = products.length - 1;
        while (left <= right)
        {
            int mid = (left + right) / 2;
            int compare = products[mid].productName.compareToIgnoreCase(name);
            if (compare == 0)
                return products[mid];
            else if (compare < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return null;
    }

    public static void main(String[] args)
    {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Mouse", "Electronics"),
            new Product(3, "Book", "Education"),
            new Product(4, "Chair", "Furniture")
        };

        // Sort before binary search
        Arrays.sort(products, Comparator.comparing(p -> p.productName));

        // Linear Search
        Product found1 = linearSearch(products, "Laptop");
        System.out.println("Linear Search Result: " + (found1 != null ? found1 : "Not found"));

        // Binary Search
        Product found2 = binarySearch(products, "Book");
        System.out.println("Binary Search Result: " + (found2 != null ? found2 : "Not found"));
    }
}
