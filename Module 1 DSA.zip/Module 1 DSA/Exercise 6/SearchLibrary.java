import java.util.Arrays;
import java.util.Comparator;

public class SearchLibrary {

    // Linear Search by Title
    public static Book linearSearch(Book[] books, String title) {
        for (Book book : books) {
            if (book.title.equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary Search by Title (sorted)
    public static Book binarySearch(Book[] books, String title) {
        int low = 0, high = books.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            int cmp = books[mid].title.compareToIgnoreCase(title);
            if (cmp == 0)
                return books[mid];
            else if (cmp < 0)
                low = mid + 1;
            else
                high = mid - 1;
        }
        return null;
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book(1, "Java Programming", "James Gosling"),
            new Book(2, "C# Essentials", "Anders Hejlsberg"),
            new Book(3, "Python Basics", "Guido van Rossum"),
            new Book(4, "Data Structures", "Robert Lafore")
        };

        System.out.println("Linear Search for 'Python Basics':");
        Book foundLinear = linearSearch(books, "Python Basics");
        System.out.println(foundLinear != null ? foundLinear : "Not Found");

        // Sort books by title for binary search
        Arrays.sort(books, Comparator.comparing(b -> b.title));

        System.out.println("\nBinary Search for 'Python Basics':");
        Book foundBinary = binarySearch(books, "Python Basics");
        System.out.println(foundBinary != null ? foundBinary : "Not Found");
    }
}
