public class StrategyTest {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Use Credit Card
        context.setStrategy(new CreditCardPayment("1234567890123456"));
        context.processPayment(2500.00);

        // Switch to PayPal
        context.setStrategy(new PayPalPayment("user@example.com"));
        context.processPayment(1800.50);
    }
}
