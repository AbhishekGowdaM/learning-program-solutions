public class BuilderTest {
    public static void main(String[] args) {
        // Basic configuration
        Computer basicComputer = new Computer.Builder("Intel i3")
                .setRAM(8)
                .setStorage(256)
                .build();

        // High-end configuration
        Computer gamingRig = new Computer.Builder("Intel i9")
                .setRAM(32)
                .setStorage(1000)
                .setGraphicsCard(true)
                .setWifiCard(true)
                .build();

        System.out.println("Basic Computer: " + basicComputer);
        System.out.println("Gaming Computer: " + gamingRig);
    }
}
