public class Computer {
    // Required and optional parts
    private final String CPU;
    private final int RAM;
    private final int storage;
    private final boolean graphicsCard;
    private final boolean wifiCard;

    // Private constructor to force use of builder
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.graphicsCard = builder.graphicsCard;
        this.wifiCard = builder.wifiCard;
    }

    // Static nested Builder class
    public static class Builder {
        private String CPU;
        private int RAM;
        private int storage;
        private boolean graphicsCard;
        private boolean wifiCard;

        public Builder(String CPU) {
            this.CPU = CPU;
        }

        public Builder setRAM(int RAM) {
            this.RAM = RAM;
            return this;
        }

        public Builder setStorage(int storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGraphicsCard(boolean graphicsCard) {
            this.graphicsCard = graphicsCard;
            return this;
        }

        public Builder setWifiCard(boolean wifiCard) {
            this.wifiCard = wifiCard;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + "GB, Storage=" + storage +
               "GB, GraphicsCard=" + graphicsCard + ", WiFi=" + wifiCard + "]";
    }
}
