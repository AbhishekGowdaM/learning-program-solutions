public class ProxyTest {
    public static void main(String[] args) {
        Image image = new ProxyImage("sample_photo.jpg");

        // Image will be loaded from disk
        image.display();

        System.out.println("---");

        // Image will NOT be loaded from disk again (cached)
        image.display();
    }
}
