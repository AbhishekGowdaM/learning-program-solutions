public class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public Customer findCustomerById(String id) {
        // Dummy data
        return new Customer(id, "Rahul Sharma", "rahul@example.com");
    }
}
