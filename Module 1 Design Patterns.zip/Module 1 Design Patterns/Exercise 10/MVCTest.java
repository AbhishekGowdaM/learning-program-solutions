public class MVCTest {
    public static void main(String[] args) {
        // Create Model
        Student student = new Student("Abhishek", "S123", "A");

        // Create View
        StudentView view = new StudentView();

        // Create Controller
        StudentController controller = new StudentController(student, view);

        // Initial display
        controller.updateView();

        System.out.println("--- Updating student info ---");
        controller.setStudentName("Abhi Gowda");
        controller.setStudentGrade("A+");

        // Updated display
        controller.updateView();
    }
}
