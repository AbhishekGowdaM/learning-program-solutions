public class DecoratorTest {
    public static void main(String[] args) {
        // Base notifier
        Notifier email = new EmailNotifier();

        // Add SMS functionality
        Notifier emailWithSMS = new SMSNotifierDecorator(email);

        // Add Slack on top of Email + SMS
        Notifier fullNotifier = new SlackNotifierDecorator(emailWithSMS);

        // Send notification
        fullNotifier.send("System update at 9 PM.");
    }
}
