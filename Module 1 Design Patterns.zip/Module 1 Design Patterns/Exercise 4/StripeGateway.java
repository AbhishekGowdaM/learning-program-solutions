public class StripeGateway {
    public void makePayment(double value) {
        System.out.println("Paid ₹" + value + " via Stripe.");
    }
}
