public class ObserverTest {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobile = new MobileApp("M1");
        Observer web = new WebApp("W1");

        stockMarket.registerObserver(mobile);
        stockMarket.registerObserver(web);

        stockMarket.setStockPrice("TCS", 3580.75);
        System.out.println("---");
        stockMarket.setStockPrice("INFY", 1490.30);
    }
}
