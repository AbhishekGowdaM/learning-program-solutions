public class WebApp implements Observer {
    private String webId;

    public WebApp(String webId) {
        this.webId = webId;
    }

    @Override
    public void update(String stockSymbol, double price) {
        System.out.println("Web App [" + webId + "] - " + stockSymbol + " updated to ₹" + price);
    }
}
